<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <title>Document</title>
</head>
<body>
    <div class="wrapper">
			<div class="inner">
				<form id="formulario" method="post" action="admin/panel/index.html">
                <br>
					<h3>Iniciar sesión</h3>
		
					<label class="form-group">
						<input type="text" class="form-control"  required>
						<span>USUARIO:</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="password" class="form-control"  required>
						<span for="">CONTRASEÑA:</span>
						<span class="border"></span>
					</label>
					<button>ENTRAR 
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
				</form>
			</div>
		</div>
		
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>
