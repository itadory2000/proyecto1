<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>RegistrationForm_v7 by Colorlib</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- MATERIAL DESIGN ICONIC FONT -->
		<link rel="stylesheet" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style1.css">
	</head>

	<body>

		<div class="wrapper">
			<div class="inner">
				<form id="formulario" method="post" action="admin/panel/index.html">
                <br>
					<h3>Iniciar sesión</h3>
		
					<label class="form-group">
						<input type="text" class="form-control"  required>
						<span>USUARIO:</span>
						<span class="border"></span>
					</label>
					<label class="form-group">
						<input type="password" class="form-control"  required>
						<span for="">CONTRASEÑA:</span>
						<span class="border"></span>
					</label>
					<button>ENTRAR 
						<i class="zmdi zmdi-arrow-right"></i>
					</button>
				</form>
			</div>
		</div>
		
	</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>