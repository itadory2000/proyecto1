<?php
include ('conexion.php');
$vnombres=$_POST['nombres'];
$vapellidos=$_POST['apellidos'];
$vcorreo=$_POST['correo'];
$vtelefono=$_POST['telefono'];
$vdireccion=$_POST['direccion'];
$vfecharegistro=$_POST['fecharegistro'];
$vusuario=$_POST['usuario'];
$vcontraseña=$_POST['contraseña'];

$conexionp=conectar_bd('localhost', 'root', '', 'proyecto_bd' );
$resultado=consulta($conexionp,"insert into cliente(nombres,apellidos,correo,telefono,direccion,fecha registro,usuario, contrseña)
 values('{$vnombres}','{$vapellidos}','{$correo}','{$vtelefono}','{$vdireccion}','{$fecharegistro}','{$usuario}', '{$contraseña}')");

if($resultado);
{
    echo"guardado exitoso";
}
?>
